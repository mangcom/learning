# คู่มือศึกษาโปรเจกต์: JWT Auth Lab

เอกสารนี้พาไล่ตั้งแต่ `npm install` จนถึงเปิดหน้าเว็บใช้งานได้จริง
พร้อมชี้จุดเชื่อมโยงของโค้ดแต่ละไฟล์ (`ไฟล์:บรรทัด`) เพื่อให้กดตามไปอ่านเองได้

## ภาพรวมสถาปัตยกรรม

```
┌──────────────┐      HTTP/JSON       ┌──────────────────┐      SQL      ┌──────────────┐
│   Browser    │  ───────────────▶   │   Express Server   │ ───────────▶ │   MariaDB     │
│  public/*    │  ◀───────────────   │   auth-server.js   │ ◀─────────── │  (users table)│
└──────────────┘      JWT token       └──────────────────┘               └──────────────┘
                                              │
                                              ▼
                                          db.js (connection pool)
```

- **`public/`** = หน้าเว็บที่ผู้ใช้คลิก (HTML/CSS/JS ฝั่ง browser)
- **`auth-server.js`** = REST API หลัก (route + middleware ตรวจสอบสิทธิ์)
- **`db.js`** = ตัวกลางคุยกับฐานข้อมูล
- **`db/init.sql`** = โครงสร้างตาราง `users` ที่ MariaDB สร้างให้อัตโนมัติตอนเริ่มครั้งแรก
- **`Dockerfile` / `docker-compose.yml`** = สั่งให้ทั้งระบบรันเป็น container

---

## Step 0 — โครงสร้างไฟล์ที่ต้องรู้จัก

| ไฟล์ | หน้าที่ |
|---|---|
| `package.json` | รายการ dependency + คำสั่ง `npm start` |
| `.env` / `.env.example` | ค่าตั้งค่า (JWT secret, ข้อมูลเชื่อมต่อ DB) |
| `db/init.sql` | schema ตาราง `users` |
| `db.js` | MariaDB connection pool + ฟังก์ชันรอ DB พร้อม |
| `auth-server.js` | Express app: routes + middleware ตรวจสอบ JWT/role |
| `public/index.html` | โครงหน้าเว็บ (แท็บ, ฟอร์ม, ปุ่ม) |
| `public/style.css` | สไตล์หน้าเว็บ |
| `public/app.js` | logic ฝั่ง browser: เรียก API, จัดการ token, อัปเดตหน้าจอ |
| `Dockerfile` | ขั้นตอน build image ของ Node.js app |
| `docker-compose.yml` | รวม service `app` + `mariadb` เข้าด้วยกัน |

---

## Step 1 — `npm install`

```bash
npm install
```

อ่านรายการ dependency จาก `package.json:11-17` แล้วติดตั้งลง `node_modules/`:

- `express` — web framework สร้าง route/middleware
- `bcryptjs` — แฮชรหัสผ่าน
- `jsonwebtoken` — สร้าง/ตรวจสอบ JWT
- `mysql2` — driver เชื่อมต่อ MariaDB (ใช้ตัวแบบ promise ผ่าน `require('mysql2/promise')` ที่ `db.js:3`)
- `dotenv` — โหลดค่าใน `.env` เข้า `process.env`

> คำสั่งนี้จำเป็นทั้งตอนพัฒนาบนเครื่องโดยตรง **และ** ถูกเรียกซ้ำอีกครั้งตอน build
> Docker image ที่ `Dockerfile:6` (`RUN npm install --omit=dev`) — เพราะ image ของ container
> เป็นคนละ filesystem กับเครื่องเรา ต้องติดตั้งแยกต่างหาก

## Step 2 — ตั้งค่า `.env`

```bash
cp .env.example .env
```

ค่าที่สำคัญ (ดูตัวอย่างใน `.env.example`):

- `JWT_SECRET` — กุญแจเซ็นลายเซ็น JWT ถูกใช้ที่ `auth-server.js:15` แล้วส่งต่อไปใช้ตอน
  สร้าง token (`auth-server.js:89`) และตอนตรวจสอบ token (`auth-server.js:114`)
- `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME` — ถูกอ่านโดย `db.js:8-12` เพื่อสร้าง
  connection pool ไปยัง MariaDB
- `DB_ROOT_PASSWORD` — ใช้เฉพาะตอน MariaDB container สร้างตัวเองครั้งแรก
  (อ้างอิงใน `docker-compose.yml:7`)

## Step 3 — สั่งรันทั้งระบบด้วย Docker

```bash
docker compose up -d --build
```

ลำดับเหตุการณ์ที่เกิดขึ้นจริง:

1. **Build image ของ app** ตาม `Dockerfile` — copy `package.json` → `npm install` → copy
   โค้ดทั้งหมด (รวม `public/`) → กำหนดคำสั่งเริ่มต้นเป็น `node auth-server.js` (`Dockerfile:12`)
2. **เริ่ม container `mariadb`** ก่อน (`docker-compose.yml:2-20`) — ครั้งแรกที่สร้าง container
   MariaDB จะรันไฟล์ `db/init.sql` ให้อัตโนมัติ (mount ไว้ที่
   `docker-compose.yml:13`) ทำให้ตาราง `users` ถูกสร้างขึ้นตาม schema ใน `db/init.sql:1-7`
3. Docker compose **รอจน MariaDB "healthy"** (`docker-compose.yml:16-20` +
   `depends_on.condition: service_healthy` ที่ `docker-compose.yml:31-33`) ก่อนจะเริ่ม container `app`
4. **Container `app` เริ่มทำงาน** → รัน `auth-server.js` → เรียก `start()` ที่บรรทัด
   `auth-server.js:165-170` → ฟังก์ชันนี้เรียก `waitForDb()` (นิยามที่ `db.js:20-39`) ก่อนเสมอ
   เพื่อความชัวร์ว่าต่อฐานข้อมูลได้จริง (ลองซ้ำได้สูงสุด 15 ครั้ง)
5. เมื่อต่อ DB สำเร็จ จะเห็น log `เชื่อมต่อ MariaDB สำเร็จ` (`db.js:28`) แล้ว Express
   จะเปิดพอร์ต 3000 รอรับ request (`auth-server.js:167-169`)

ตรวจสอบว่าเสร็จแล้วด้วย:

```bash
docker compose logs -f app     # รอจนเห็น "JWT auth lab server running on..."
curl http://localhost:3000/health
```

## Step 4 — เปิดหน้าเว็บ

เปิดเบราว์เซอร์ไปที่ **`http://localhost:3000`**

- Express ทำหน้าที่เสิร์ฟไฟล์ static ผ่าน `app.use(express.static(...))` ที่ `auth-server.js:12`
  ซึ่งชี้ไปที่โฟลเดอร์ `public/` — ทำให้ browser ขอ `/` แล้วได้ `public/index.html` กลับมา
- `index.html` โหลด `style.css` (`public/index.html:7`) และ `app.js` (`public/index.html:82`)
- ทันทีที่ `app.js` ถูกโหลด จะรันโค้ดส่วน **Init** ที่ `public/app.js:217-219`:
  เรียก `updateUserBadge()` เพื่อเช็คว่ามี token ค้างใน `localStorage` จากครั้งก่อนไหม
  (ถ้ามีและยังไม่หมดอายุ จะพาไปแท็บโปรไฟล์ทันที)

## Step 5 — คลิก "สมัครสมาชิก" (Register)

ไล่โค้ดตามลำดับที่ทำงานจริง:

1. ผู้ใช้กรอกฟอร์มแล้วกดปุ่ม submit → trigger event listener ที่
   **`public/app.js:113`** (`register-form` submit handler)
2. อ่านค่าจากฟอร์มมาเป็น `body` (`public/app.js:117-121`) แล้วเรียก
   `apiFetch('/api/register', ...)` — ฟังก์ชันกลางที่นิยามไว้ที่ **`public/app.js:36-49`**
   ทำหน้าที่แนบ header และยิง `fetch()` จริง
3. ฝั่ง server รับที่ route **`auth-server.js:21`** (`POST /api/register`)
   - ตรวจ username/password ว่าง (`auth-server.js:26-28`)
   - แฮชรหัสผ่านด้วย `bcrypt.hash()` (`auth-server.js:32`) — เป็น one-way hash
   - บันทึกลง MariaDB ด้วย `pool.execute(INSERT ...)` (`auth-server.js:37-40`) โดย
     `pool` มาจาก `db.js:7` (import ที่ `auth-server.js:8`)
   - ตาราง `users` ที่ query ลงไปคือตัวเดียวกับที่สร้างไว้ใน `db/init.sql:1-7`
     (คอลัมน์ `username` มี `UNIQUE` — ถ้าซ้ำ MariaDB จะโยน error code `ER_DUP_ENTRY`
     ซึ่งถูกดักไว้ที่ `auth-server.js:49-51` แล้วตอบ `409 Conflict`)
4. ผลลัพธ์ (`201 Created` หรือ error) กลับไปที่ `apiFetch` → แสดงผลผ่าน
   `showResult()` (`public/app.js:52-58`) ในกล่อง `#register-result` — ถ้าสำเร็จจะเติม
   username ให้อัตโนมัติในแท็บ login (`public/app.js:134`)

## Step 6 — คลิก "เข้าสู่ระบบ" (Login)

1. Submit handler ที่ **`public/app.js:142`** เก็บ username/password แล้วเรียก
   `apiFetch('/api/login', ...)`
2. ฝั่ง server รับที่ route **`auth-server.js:59`** (`POST /api/login`)
   - ค้นหา user ด้วย `SELECT ... WHERE username = ?` (`auth-server.js:69-72`)
   - เทียบรหัสผ่านด้วย `bcrypt.compare()` (`auth-server.js:81`) — เทียบกับ hash
     ที่เก็บไว้ตอน register ไม่มีการถอดรหัสกลับ
   - ถ้าถูกต้อง สร้าง payload (`id`, `username`, `role`) แล้วเซ็นเป็น JWT ด้วย
     `jwt.sign()` (`auth-server.js:89`) โดยใช้ `JWT_SECRET` และอายุ `JWT_EXPIRES_IN`
     จาก `.env`
3. Token ที่ได้กลับมาถูกเก็บด้วย `setToken()` (`public/app.js:161`, นิยามที่
   `public/app.js:10-12`) ลงใน `localStorage` ของ browser
4. เรียก `updateUserBadge()` (`public/app.js:82-98`) ทันที — ฟังก์ชันนี้ **decode JWT
   ฝั่ง client เอง** ด้วย `decodeJwtPayload()` (`public/app.js:20-33`, ใช้ `atob()` แกะ
   base64url ของส่วน payload) เพื่อเอา `username`/`role` มาแสดงเป็น badge สีบนหัวเว็บ
   (การ decode ฝั่งนี้ใช้ "แสดงผล" เท่านั้น — การตรวจสอบลายเซ็นจริงเกิดที่ server เสมอ)
5. พาไปแท็บโปรไฟล์และกดปุ่มโหลดโปรไฟล์ให้อัตโนมัติ (`public/app.js:163-164`)

## Step 7 — แท็บ "โปรไฟล์ของฉัน" (route ที่ต้อง login)

1. ปุ่ม `#load-profile-btn` เรียก `apiFetch('/api/profile')` (`public/app.js:171-174`)
   — `apiFetch` จะแนบ `Authorization: Bearer <token>` ให้อัตโนมัติ (`public/app.js:41`)
   เพราะมี `token` อยู่ใน `localStorage` แล้วจาก Step 6
2. ฝั่ง server: route `GET /api/profile` (`auth-server.js:137`) ผูก middleware
   `verifyToken` ไว้ก่อน (นิยามที่ **`auth-server.js:102-123`**)
   - middleware นี้แกะ header `Authorization`, ตัดคำว่า `Bearer` ออก (`auth-server.js:106`)
   - ใช้ `jwt.verify()` ตรวจลายเซ็นด้วย `JWT_SECRET` ตัวเดียวกับตอนสร้าง (`auth-server.js:114`)
   - ผ่านแล้วเซ็ต `req.user = decoded` (`auth-server.js:120`) แล้วเรียก `next()`
     ส่งต่อให้ route handler จริง (`auth-server.js:137-140`) ซึ่งแค่ส่ง `req.user` กลับไป

## Step 8 — แท็บ "Admin Dashboard" (ทดสอบ RBAC)

นี่คือจุดที่โชว์ **Role-Based Access Control** ให้เห็นผลจริงบนหน้าจอ:

1. ปุ่ม "เรียก GET /api/admin-dashboard" → `public/app.js:179-182`
   ปุ่ม "โหลดรายชื่อ user ทั้งหมด" → `public/app.js:185-213` (เรียก `/api/users`)
2. ทั้งสอง route ฝั่ง server ผูก middleware สองชั้นเรียงกัน:
   ```js
   app.get('/api/admin-dashboard', verifyToken, isAdmin, (req, res) => {...})  // auth-server.js:143
   app.get('/api/users',           verifyToken, isAdmin, async (req, res) => {...})  // auth-server.js:148
   ```
   - ผ่าน `verifyToken` ก่อน (เหมือน Step 7) เพื่อยืนยันว่า login จริง
   - ต่อด้วย `isAdmin` (นิยามที่ **`auth-server.js:127-132`**) ตรวจว่า
     `req.user.role === 'admin'` — ถ้าไม่ใช่ ตอบ `403 Forbidden` ทันที
3. ผลลัพธ์ที่ได้แสดงผ่าน `showResult()` เป็นกล่อง **สีแดง (error) เมื่อ role เป็น
   member** และ **สีเขียว (success) เมื่อ role เป็น admin** (คุมด้วย CSS class
   `.result.success` / `.result.error` ใน `public/style.css`)
4. ถ้าเป็น admin และกดปุ่มโหลดรายชื่อ user, response ที่ได้ (`{ users: [...] }`
   มาจาก `auth-server.js:151-154` ซึ่ง `SELECT` ทุกคอลัมน์ *ยกเว้น* `password`)
   จะถูกวนลูปสร้างเป็นแถวตาราง (`public/app.js:201-211`)

## Step 9 — ออกจากระบบ / รีเซ็ตข้อมูล

- ปุ่ม "ออกจากระบบ" → `public/app.js:101-108` → ลบ token จาก `localStorage`
  (`clearToken()` ที่ `public/app.js:15-17`) แล้วเคลียร์ผลลัพธ์ที่ค้างอยู่บนหน้าจอ
- รีเซ็ตฐานข้อมูลทั้งหมด (ลบ user ทุกคนที่เคยสมัคร):
  ```bash
  docker compose down -v   # -v ลบ volume mariadb_data ด้วย ⇒ ตาราง users ว่างใหม่
  docker compose up -d --build
  ```

---

## แผนที่การเชื่อมโยง (Quick Reference)

| ทำอะไร | หน้าเว็บ (คลิกที่ไหน) | Frontend JS | API Route | Middleware | ตาราง/คอลัมน์ที่ query |
|---|---|---|---|---|---|
| สมัครสมาชิก | ปุ่ม "สมัครสมาชิก" | `app.js:113` | `auth-server.js:21` POST `/api/register` | - | INSERT `users` |
| เข้าสู่ระบบ | ปุ่ม "เข้าสู่ระบบ" | `app.js:142` | `auth-server.js:59` POST `/api/login` | - | SELECT `users` |
| ดูโปรไฟล์ | ปุ่ม "โหลดข้อมูลโปรไฟล์" | `app.js:171` | `auth-server.js:137` GET `/api/profile` | `verifyToken` | - |
| Admin dashboard | ปุ่ม "เรียก GET /api/admin-dashboard" | `app.js:179` | `auth-server.js:143` | `verifyToken` → `isAdmin` | - |
| รายชื่อ user ทั้งหมด | ปุ่ม "โหลดรายชื่อ user ทั้งหมด" | `app.js:185` | `auth-server.js:148` GET `/api/users` | `verifyToken` → `isAdmin` | SELECT `users` (ไม่รวม password) |
| ออกจากระบบ | ปุ่ม "ออกจากระบบ" | `app.js:101` | (ไม่เรียก API) | - | - |

## สรุป lifecycle ของ JWT token ในระบบนี้

```
register (auth-server.js:21)
   │  bcrypt.hash password → เก็บลง MariaDB
   ▼
login (auth-server.js:59)
   │  bcrypt.compare → jwt.sign(payload, JWT_SECRET) ────▶ token ส่งกลับ browser
   ▼
browser เก็บ token ใน localStorage (app.js:10)
   │
   ▼
ทุก request ที่ต้อง login: apiFetch แนบ "Authorization: Bearer <token>" (app.js:41)
   │
   ▼
server: verifyToken (auth-server.js:102) ตรวจลายเซ็นด้วย JWT_SECRET ตัวเดิม
   │
   ├─ ผ่าน → req.user = decoded → route handler ทำงานต่อ
   └─ ไม่ผ่าน/หมดอายุ → 403 Forbidden
```

จุดสำคัญที่ต้องเข้าใจ: **`JWT_SECRET` ตัวเดียว** (ตั้งใน `.env`) ถูกใช้ทั้งตอน
"เซ็น" token (login) และตอน "ตรวจ" token (ทุก route ที่มี `verifyToken`) — ถ้าเปลี่ยนค่า
`JWT_SECRET` แล้ว restart server, token เก่าที่เคย login ไว้จะตรวจไม่ผ่านทันที
(ต้อง login ใหม่)
