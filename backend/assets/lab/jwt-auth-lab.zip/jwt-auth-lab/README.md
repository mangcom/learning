# JWT Auth Lab (Unit 8) — MariaDB + Docker

ระบบ Authentication & Authorization ด้วย Node.js + Express + bcryptjs + jsonwebtoken
เชื่อมต่อฐานข้อมูล MariaDB จริง และแพ็กเป็น Docker (app + db) ตามเนื้อหา
https://apps.bncc.ac.th/learning/backend/unit8.php

## โครงสร้างโปรเจกต์

```
.
├── auth-server.js      # Express app: routes + middlewares
├── db.js               # MariaDB connection pool (mysql2) + retry เมื่อ DB ยังไม่พร้อม
├── db/init.sql          # schema ตาราง users (รันอัตโนมัติตอน MariaDB container สร้างครั้งแรก)
├── public/              # หน้าเว็บ UI (register/login/profile/admin dashboard)
│   ├── index.html
│   ├── style.css
│   └── app.js
├── Dockerfile           # image ของ Node.js app
├── docker-compose.yml   # รวม service app + mariadb
├── .env                 # ค่า config จริง (ไม่ commit ขึ้น git)
└── .env.example         # ตัวอย่างค่า config
```

## หน้าเว็บ UI

เปิด `http://localhost:3000` ในเบราว์เซอร์ จะมีหน้าเว็บให้คลิกทดสอบได้ทันทีโดยไม่ต้องใช้ Postman:

- **สมัครสมาชิก** — ฟอร์ม register (เลือก role member/admin ได้เพื่อทดสอบ RBAC)
- **เข้าสู่ระบบ** — ฟอร์ม login ได้ JWT token เก็บไว้ใน localStorage อัตโนมัติ
- **โปรไฟล์ของฉัน** — เรียก `GET /api/profile` แสดงข้อมูล user ที่ decode จาก token
- **Admin Dashboard** — ปุ่มเรียก `GET /api/admin-dashboard` และ `GET /api/users` (รายชื่อ user
  ทั้งหมดพร้อม role) เพื่อทดสอบ RBAC แบบเห็นผลจริง: login ด้วย user role `member` จะขึ้น
  กล่องสีแดง (403 Forbidden) ส่วน role `admin` จะขึ้นกล่องสีเขียว (200 พร้อมข้อมูล)

มุมขวาบนจะแสดง badge ของผู้ใช้ที่ login อยู่พร้อม role (สีน้ำเงิน = member, สีทอง = admin)
และปุ่มออกจากระบบ

## รันด้วย Docker (แนะนำ)

ต้องมี Docker Desktop / Docker Engine + Compose plugin

```bash
# คัดลอกไฟล์ env ตัวอย่าง แล้วแก้ค่า JWT_SECRET / รหัสผ่าน DB ตามต้องการ
cp .env.example .env

# build image และรันทั้ง app + mariadb
docker compose up -d --build

# ดู log ของ app (รอจนเห็น "เชื่อมต่อ MariaDB สำเร็จ")
docker compose logs -f app
```

Server จะรันที่ `http://localhost:3000`, MariaDB expose ที่ `localhost:3306`

ตาราง `users` จะถูกสร้างอัตโนมัติจาก `db/init.sql` ตอน container ของ MariaDB
ถูกสร้างครั้งแรก (ถ้าเคยรันมาก่อนแล้วอยาก reset ฐานข้อมูล ให้ลบ volume ด้วย
`docker compose down -v`)

### คำสั่งที่ใช้บ่อย

```bash
docker compose down          # หยุด container (เก็บข้อมูลใน volume ไว้)
docker compose down -v       # หยุด + ลบข้อมูลใน MariaDB ทั้งหมด (reset)
docker compose logs -f app   # ดู log ของ app แบบ real-time
docker exec -it jwt_lab_mariadb mariadb -u jwt_user -p jwt_lab   # เข้า MariaDB shell
```

## รันแบบไม่ใช้ Docker (ต้องมี MariaDB รันเองอยู่แล้ว)

```bash
npm install
# แก้ .env ให้ DB_HOST=localhost และตั้งค่าตาม MariaDB ของเครื่อง
# สร้างตารางด้วย: mysql -u root -p < db/init.sql  (ต้องสร้าง database ชื่อ jwt_lab ไว้ก่อน)
npm start
```

## Endpoints

| Method | Route                  | Auth ที่ต้องมี         | คำอธิบาย                        |
|--------|-------------------------|-------------------------|----------------------------------|
| GET    | `/health`                | -                        | ตรวจสอบว่า server ทำงานอยู่      |
| POST   | `/api/register`         | -                        | สมัครสมาชิก (body: username, password, role ไม่บังคับ) |
| POST   | `/api/login`             | -                        | เข้าสู่ระบบ ได้ JWT token กลับมา |
| GET    | `/api/profile`           | Bearer Token             | ดูข้อมูลผู้ใช้ที่ login อยู่     |
| GET    | `/api/admin-dashboard`   | Bearer Token + role admin| เฉพาะ admin เท่านั้น (RBAC)      |
| GET    | `/api/users`              | Bearer Token + role admin| รายชื่อ user ทั้งหมดพร้อม role (เฉพาะ admin) |

## ทดสอบด้วย curl

```bash
# 1. สมัครสมาชิก member ปกติ
curl -X POST http://localhost:3000/api/register \
  -H "Content-Type: application/json" \
  -d '{"username":"somchai","password":"1234"}'

# 2. สมัครสมาชิก admin (สำหรับทดสอบ RBAC)
curl -X POST http://localhost:3000/api/register \
  -H "Content-Type: application/json" \
  -d '{"username":"boss","password":"1234","role":"admin"}'

# 3. Login แล้วคัดลอก token ที่ได้
curl -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"somchai","password":"1234"}'

# 4. เรียก /profile โดยไม่มี token -> ต้องได้ 403
curl http://localhost:3000/api/profile

# 5. เรียก /profile พร้อม token -> เข้าได้
curl http://localhost:3000/api/profile \
  -H "Authorization: Bearer <TOKEN_ที่ได้จากขั้นตอน 3>"

# 6. เรียก /admin-dashboard ด้วย token ของ member -> ต้องได้ 403
curl http://localhost:3000/api/admin-dashboard \
  -H "Authorization: Bearer <TOKEN_ของ somchai>"

# 7. เรียก /admin-dashboard ด้วย token ของ admin -> เข้าได้
curl http://localhost:3000/api/admin-dashboard \
  -H "Authorization: Bearer <TOKEN_ของ boss>"
```

## ทดสอบด้วย Postman

1. `POST /api/register` — สมัครสมาชิกอย่างน้อย 2 คน: role `member` และ role `admin`
2. `POST /api/login` — login ทีละคน คัดลอก `token` ที่ได้
3. `GET /api/profile` โดยไม่ใส่ Token → คาดหวัง `403 Forbidden`
4. `GET /api/profile` ใส่ Token ใน tab **Authorization → Bearer Token** → คาดหวัง `200 OK`
5. `GET /api/admin-dashboard` ด้วย token ของ member → คาดหวัง `403 Forbidden`
6. `GET /api/admin-dashboard` ด้วย token ของ admin → คาดหวัง `200 OK`

## จุดสำคัญตามเนื้อหา

- **bcryptjs**: แฮชรหัสผ่านแบบทางเดียว (one-way) พร้อม salt อัตโนมัติ ป้องกัน rainbow table attack — เก็บเฉพาะ hash ใน MariaDB ไม่เคยเก็บ plaintext
- **JWT structure**: `Header.Payload.Signature` — payload เก็บเฉพาะ `id`, `username`, `role` ไม่เก็บรหัสผ่านหรือข้อมูลลับ
- **verifyToken**: middleware ตรวจสอบ `Authorization: Bearer <token>` และ decode ใส่ `req.user`
- **isAdmin**: middleware ที่ chain ต่อจาก `verifyToken` เพื่อตรวจสอบ `req.user.role === 'admin'` (RBAC ตามใบงานที่ 8)
- **MariaDB**: username มี `UNIQUE` constraint ที่ระดับฐานข้อมูล กันสมัครซ้ำแม้มี concurrent request; connection ใช้ pool (`mysql2/promise`) พร้อม retry ตอนเริ่ม server เผื่อ MariaDB container ยังไม่พร้อม
- **Docker**: `docker-compose.yml` รัน MariaDB พร้อม healthcheck และให้ app service รอจน DB healthy (`depends_on.condition: service_healthy`) ก่อนค่อย start; ข้อมูลเก็บถาวรใน named volume `mariadb_data`
