// โหลดค่าตัวแปรจากไฟล์ .env เข้ามาใส่ใน process.env (ต้องเรียกก่อนใช้ process.env ตัวอื่น ๆ)
require('dotenv').config();

const path = require('path'); // ใช้ประกอบ path ของโฟลเดอร์ public ให้ถูกต้องทุก OS
const express = require('express'); // web framework หลักที่ใช้สร้าง REST API
const bcrypt = require('bcryptjs'); // ใช้ hash และเปรียบเทียบรหัสผ่านแบบปลอดภัย (one-way)
const jwt = require('jsonwebtoken'); // ใช้สร้างและตรวจสอบ JWT token
const { pool, waitForDb } = require('./db'); // connection pool ของ MariaDB + ฟังก์ชันรอ DB พร้อม

const app = express(); // สร้าง instance ของ Express application
app.use(express.json()); // middleware แปลง body ของ request ที่เป็น JSON ให้กลายเป็น req.body อัตโนมัติ
app.use(express.static(path.join(__dirname, 'public'))); // เสิร์ฟไฟล์หน้าเว็บ (html/css/js) จากโฟลเดอร์ public ให้ browser เรียกได้ตรง ๆ

const PORT = process.env.PORT || 3000; // พอร์ตที่ server จะฟัง (ถ้าไม่ตั้งค่าใน .env ใช้ 3000)
const JWT_SECRET = process.env.JWT_SECRET; // กุญแจลับสำหรับเซ็นและตรวจสอบลายเซ็นของ JWT (ห้ามรั่วไหล)
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '1h'; // อายุของ token ก่อนหมดอายุ (ถ้าไม่ตั้งค่าใช้ 1 ชั่วโมง)

// ---------- Auth routes ----------

// POST /api/register — สมัครสมาชิกใหม่
app.post('/api/register', async (req, res) => {
  // ดึงค่า username, password, role ที่ client ส่งมาใน body ออกมา
  const { username, password, role } = req.body;

  // ตรวจสอบข้อมูลเบื้องต้น: ถ้าไม่ส่ง username หรือ password มา ให้ตอบ 400 Bad Request ทันที
  if (!username || !password) {
    return res.status(400).json({ message: 'username และ password จำเป็นต้องระบุ' });
  }

  try {
    // แฮชรหัสผ่านด้วย bcrypt (10 = salt rounds ยิ่งมากยิ่งปลอดภัยแต่ยิ่งช้า) — ผลลัพธ์เป็น one-way hash ถอดกลับไม่ได้
    const hashedPassword = await bcrypt.hash(password, 10);
    // จำกัดค่า role ให้เป็นได้แค่ 'admin' หรือ 'member' เท่านั้น ป้องกันค่าแปลก ๆ หลุดเข้า DB
    const safeRole = role === 'admin' ? 'admin' : 'member';

    // บันทึกผู้ใช้ใหม่ลงตาราง users ด้วย prepared statement (เครื่องหมาย ? กัน SQL injection)
    const [result] = await pool.execute(
      'INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
      [username, hashedPassword, safeRole]
    );

    // ตอบกลับ 201 Created พร้อมข้อมูล user ที่สร้างสำเร็จ (ไม่ส่ง password กลับไปเด็ดขาด)
    res.status(201).json({
      message: 'สมัครสมาชิกสำเร็จ',
      user: { id: result.insertId, username, role: safeRole },
    });
  } catch (err) {
    // ER_DUP_ENTRY คือ error ของ MariaDB ตอนชนกับ UNIQUE constraint (username ซ้ำ)
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'username นี้ถูกใช้ไปแล้ว' });
    }
    // error อื่น ๆ ที่ไม่คาดคิด (เช่น DB ล่ม) ให้ log ไว้ดูฝั่ง server แล้วตอบ 500
    console.error(err);
    res.status(500).json({ message: 'เกิดข้อผิดพลาดของเซิร์ฟเวอร์' });
  }
});

// POST /api/login — เข้าสู่ระบบด้วย username/password แล้วแลกกับ JWT token
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  // ตรวจสอบข้อมูลเบื้องต้นเหมือนตอน register
  if (!username || !password) {
    return res.status(400).json({ message: 'username และ password จำเป็นต้องระบุ' });
  }

  try {
    // ค้นหา user จาก username ที่ส่งมา (ใช้ prepared statement เช่นกัน)
    const [rows] = await pool.execute(
      'SELECT id, username, password, role FROM users WHERE username = ?',
      [username]
    );
    const user = rows[0]; // ถ้าเจอจะได้ object แถวแรก ถ้าไม่เจอจะเป็น undefined

    // ไม่พบ user ที่มี username นี้ — ตอบข้อความกลาง ๆ ไม่บอกว่า "ไม่มี username นี้" เพื่อความปลอดภัย
    if (!user) {
      return res.status(401).json({ message: 'username หรือ password ไม่ถูกต้อง' });
    }

    // เปรียบเทียบรหัสผ่านที่ผู้ใช้กรอก กับ hash ที่เก็บไว้ใน DB (bcrypt จะแฮช input แล้วเทียบให้เอง)
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'username หรือ password ไม่ถูกต้อง' });
    }

    // Payload เก็บเฉพาะข้อมูลที่ไม่ลับ ใช้สำหรับตรวจสอบสิทธิ์เท่านั้น
    const payload = { id: user.id, username: user.username, role: user.role };
    // เซ็น payload ด้วย JWT_SECRET ให้กลายเป็น token (string) ที่มีวันหมดอายุตาม JWT_EXPIRES_IN
    const token = jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

    // ส่ง token กลับไปให้ client เก็บไว้ใช้แนบกับ request ถัดไป
    res.json({ message: 'เข้าสู่ระบบสำเร็จ', token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'เกิดข้อผิดพลาดของเซิร์ฟเวอร์' });
  }
});

// ---------- Middlewares ----------

// ตรวจสอบว่ามี Bearer Token ที่ถูกต้องแนบมาใน Authorization header หรือไม่
function verifyToken(req, res, next) {
  // header ที่ client ควรส่งมามีรูปแบบ "Authorization: Bearer <token>"
  const authHeader = req.headers['authorization'];
  // แยกคำว่า "Bearer" กับตัว token ออกจากกันด้วย space แล้วเอาส่วนที่สอง (index 1) มาใช้
  const token = authHeader && authHeader.split(' ')[1]; // "Bearer <token>"

  // ไม่มี token แนบมาเลย — ปฏิเสธด้วย 403 ทันที ไม่ต้องเช็คอะไรต่อ
  if (!token) {
    return res.status(403).json({ message: 'ไม่พบ Token กรุณาเข้าสู่ระบบ' });
  }

  // ตรวจสอบลายเซ็นของ token ด้วย JWT_SECRET ตัวเดียวกับตอนสร้าง ถ้าใครแก้ payload มาจะตรวจจับได้ทันที
  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      // token ปลอมหรือหมดอายุแล้ว
      return res.status(403).json({ message: 'Token ไม่ถูกต้องหรือหมดอายุ' });
    }
    // ตรวจผ่าน — แนบข้อมูล user ที่ decode ได้ไว้ที่ req.user ให้ route ถัดไปใช้งานต่อ
    req.user = decoded;
    next(); // ส่งต่อไปยัง middleware/route handler ตัวถัดไป
  });
}

// ตรวจสอบว่า user ที่ผ่าน verifyToken มาแล้วมี role เป็น admin หรือไม่
// (ต้องเรียกต่อจาก verifyToken เสมอ เพราะต้องพึ่ง req.user ที่ verifyToken ใส่ไว้ให้)
function isAdmin(req, res, next) {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ message: 'ต้องเป็น admin เท่านั้นถึงจะเข้าถึงได้' });
  }
  next(); // เป็น admin จริง — อนุญาตให้ผ่านไป route handler ต่อ
}

// ---------- Protected routes ----------

// GET /api/profile — ต้อง login ก่อนเท่านั้น (ไม่จำกัด role) — เรียก verifyToken เป็น middleware ก่อนเข้า handler
app.get('/api/profile', verifyToken, (req, res) => {
  // ถึงตรงนี้แปลว่า token ถูกต้องแล้ว req.user คือข้อมูลที่ decode ได้จาก token
  res.json({ message: 'เข้าถึงข้อมูลส่วนตัวสำเร็จ', user: req.user });
});

// GET /api/admin-dashboard — ต้อง login และเป็น admin เท่านั้น (chain 2 middleware: verifyToken แล้วค่อย isAdmin)
app.get('/api/admin-dashboard', verifyToken, isAdmin, (req, res) => {
  res.json({ message: 'ยินดีต้อนรับสู่ admin dashboard', user: req.user });
});

// GET /api/users — รายชื่อ user ทั้งหมดพร้อม role (เฉพาะ admin) — ใช้ middleware เดียวกับข้างบน
app.get('/api/users', verifyToken, isAdmin, async (req, res) => {
  try {
    // ดึงทุกแถวจากตาราง users แต่ไม่ดึงคอลัมน์ password ออกมาเด็ดขาด (ป้องกัน hash หลุด)
    const [rows] = await pool.execute(
      'SELECT id, username, role, created_at FROM users ORDER BY id'
    );
    res.json({ users: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'เกิดข้อผิดพลาดของเซิร์ฟเวอร์' });
  }
});

// GET /health — สำหรับ docker healthcheck / ตรวจสอบสถานะเซิร์ฟเวอร์ — ไม่ต้อง login
app.get('/health', (req, res) => res.json({ status: 'ok' }));

// ฟังก์ชันเริ่มต้น server: ต้องรอให้ต่อ MariaDB ได้ก่อน ค่อยเปิดพอร์ตรับ request
async function start() {
  await waitForDb(); // รอจนกว่าจะเชื่อมต่อฐานข้อมูลได้ (หรือ throw error ถ้าลองครบจำนวนครั้งแล้วยังไม่ได้)
  app.listen(PORT, () => {
    console.log(`JWT auth lab server running on http://localhost:${PORT}`);
  });
}

// เรียกฟังก์ชันเริ่ม server — ถ้ามี error ระหว่างเริ่ม (เช่นต่อ DB ไม่ได้เลย) ให้ log แล้วปิดโปรเซสทิ้ง
start().catch((err) => {
  console.error('ไม่สามารถเริ่มเซิร์ฟเวอร์ได้:', err);
  process.exit(1);
});
