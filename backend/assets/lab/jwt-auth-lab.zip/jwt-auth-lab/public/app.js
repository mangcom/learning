// ชื่อ key ที่ใช้เก็บ JWT token ไว้ใน localStorage ของ browser
const TOKEN_KEY = 'jwt_lab_token';

// อ่าน token ปัจจุบันออกจาก localStorage (คืนค่า null ถ้ายังไม่เคย login)
function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

// บันทึก token ที่ได้จากการ login ลง localStorage เพื่อให้ยังอยู่แม้ปิด/เปิดหน้าเว็บใหม่
function setToken(token) {
  localStorage.setItem(TOKEN_KEY, token);
}

// ลบ token ออกจาก localStorage (ใช้ตอน logout)
function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

// decode ฝั่ง client เพื่อแสดงผลเท่านั้น — การตรวจสอบจริงเกิดที่ server เสมอ
function decodeJwtPayload(token) {
  try {
    // JWT มีรูปแบบ "header.payload.signature" คั่นด้วยจุด — เอาส่วนตรงกลาง (index 1) มาใช้
    const payload = token.split('.')[1];
    // payload ถูกเข้ารหัสแบบ base64url (ใช้ - และ _ แทน + และ / ของ base64 ปกติ) ต้องแปลงกลับก่อน
    // atob() คือฟังก์ชันมาตรฐานของ browser สำหรับถอดรหัส base64 ให้เป็น string ธรรมดา
    const json = atob(payload.replace(/-/g, '+').replace(/_/g, '/'));
    // แปลง JSON string ที่ได้ให้กลายเป็น object เพื่อใช้งานง่าย ๆ ใน JS
    return JSON.parse(json);
  } catch {
    // token ผิดรูปแบบหรือ decode ไม่ได้ — คืนค่า null แทนที่จะทำให้หน้าเว็บพัง
    return null;
  }
}

// ฟังก์ชันกลางสำหรับเรียก API ทุกจุดในหน้านี้ — แนบ Content-Type และ Authorization header ให้อัตโนมัติ
async function apiFetch(path, options = {}) {
  const token = getToken(); // ดึง token ปัจจุบัน (ถ้ามี) มาแนบไปกับ request
  // รวม header เริ่มต้น (Content-Type) เข้ากับ header อื่น ๆ ที่ผู้เรียกอาจส่งมาเพิ่ม
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  // ถ้ามี token อยู่แล้ว ให้แนบ Authorization: Bearer <token> ไปด้วยทุกครั้ง
  if (token) headers['Authorization'] = `Bearer ${token}`;

  // เรียก fetch จริง โดยรวม options เดิมกับ headers ที่เตรียมไว้
  const res = await fetch(path, { ...options, headers });
  // พยายามแปลง response เป็น JSON เสมอ ถ้าแปลงไม่ได้ (เช่น body ว่าง) ให้ได้ object ว่างแทนที่จะ error
  const data = await res.json().catch(() => ({}));
  // ส่งกลับข้อมูลสรุปที่ผู้เรียกใช้งานง่าย: ok (สำเร็จไหม), status (HTTP code), data (เนื้อหา JSON)
  return { ok: res.ok, status: res.status, data };
}

// แสดงผลลัพธ์การเรียก API ลงในกล่อง <pre> ที่กำหนด พร้อมเปลี่ยนสีตามผลลัพธ์ (เขียว=สำเร็จ, แดง=error)
function showResult(el, ok, status, data) {
  // แสดง HTTP status code และ JSON แบบจัดรูปแบบให้อ่านง่าย (เว้นวรรค 2 ช่อง)
  el.textContent = `HTTP ${status}\n${JSON.stringify(data, null, 2)}`;
  // ล้าง class สีเก่าออกก่อน แล้วค่อยใส่ class ใหม่ตามผลลัพธ์ล่าสุด
  el.classList.remove('success', 'error');
  el.classList.add(ok ? 'success' : 'error');
}

// ---------- Tabs ----------

// สลับไปแสดงแท็บที่ชื่อ tabName (register / login / profile / admin) และซ่อนแท็บอื่นทั้งหมด
function switchTab(tabName) {
  // ไล่ปุ่มแท็บทุกปุ่ม ใส่ class "active" เฉพาะปุ่มที่ data-tab ตรงกับ tabName ที่เลือก
  document.querySelectorAll('.tab-btn').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.tab === tabName);
  });
  // ไล่ panel เนื้อหาทุกอัน ใส่ class "active" (ซึ่งใน CSS ทำให้แสดงผล) เฉพาะ panel ที่ id ตรงกัน
  document.querySelectorAll('.tab-panel').forEach((panel) => {
    panel.classList.toggle('active', panel.id === `tab-${tabName}`);
  });
}

// ผูก event คลิกให้ทุกปุ่มแท็บ เพื่อเรียก switchTab ด้วยชื่อแท็บของปุ่มนั้น ๆ (เก็บไว้ใน data-tab attribute)
document.querySelectorAll('.tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => switchTab(btn.dataset.tab));
});

// ---------- User badge ----------

// อัปเดต badge มุมขวาบนให้ตรงกับสถานะ login ปัจจุบัน (แสดง/ซ่อน + username + role)
function updateUserBadge() {
  const badge = document.getElementById('user-badge'); // กล่อง badge ทั้งก้อน (username + ปุ่ม logout)
  const info = document.getElementById('user-info'); // span ที่จะใส่ข้อความ username + role
  const token = getToken();
  // ถ้ามี token ให้ลอง decode payload ออกมาดู ไม่มี token ก็ไม่ต้อง decode
  const payload = token ? decodeJwtPayload(token) : null;

  // ไม่มี token หรือ decode ไม่สำเร็จ แปลว่ายังไม่ได้ login (หรือ token เสีย) — ซ่อน badge ทิ้ง
  if (!payload) {
    badge.classList.add('hidden');
    return;
  }

  // มี payload ที่ decode ได้ — แสดง badge และใส่ username พร้อม role badge สีตาม role (member/admin)
  badge.classList.remove('hidden');
  info.innerHTML = `${payload.username} <span class="role-badge ${payload.role}">${payload.role}</span>`;
}

// ผูก event ให้ปุ่ม "ออกจากระบบ": ล้าง token, รีเซ็ต UI ทุกส่วนที่เคยแสดงผลลัพธ์ แล้วพากลับไปแท็บ login
document.getElementById('logout-btn').addEventListener('click', () => {
  clearToken(); // ลบ token ออกจาก localStorage
  updateUserBadge(); // บังคับให้ badge หายไป (เพราะตอนนี้ getToken() จะคืน null แล้ว)
  document.getElementById('profile-result').textContent = ''; // เคลียร์ผลลัพธ์เก่าของแท็บโปรไฟล์
  document.getElementById('admin-result').textContent = ''; // เคลียร์ผลลัพธ์เก่าของแท็บ admin
  document.getElementById('users-table').classList.add('hidden'); // ซ่อนตารางรายชื่อ user ที่เคยโหลดไว้
  switchTab('login'); // พาผู้ใช้กลับไปหน้า login
});

// ---------- Register ----------

// ผูก event "submit" ของฟอร์มสมัครสมาชิก — ทำงานเมื่อกดปุ่ม "สมัครสมาชิก"
document.getElementById('register-form').addEventListener('submit', async (e) => {
  e.preventDefault(); // กัน browser reload หน้าเว็บแบบ default เวลา submit ฟอร์ม (เราจะยิง fetch เองแทน)
  const form = e.target; // อ้างอิงถึงฟอร์มที่ถูก submit
  // อ่านค่าจาก input ในฟอร์มผ่านชื่อ (name attribute) มาประกอบเป็น body ที่จะส่งไป API
  const body = {
    username: form.username.value,
    password: form.password.value,
    role: form.role.value,
  };

  // เรียก POST /api/register พร้อมแปลง body เป็น JSON string
  const { ok, status, data } = await apiFetch('/api/register', {
    method: 'POST',
    body: JSON.stringify(body),
  });

  // แสดงผลลัพธ์ (สำเร็จ/ผิดพลาด) ในกล่องผลลัพธ์ของแท็บ register
  showResult(document.getElementById('register-result'), ok, status, data);

  if (ok) {
    // เติม username ให้อัตโนมัติในแท็บ login เพื่อความสะดวก
    document.querySelector('#login-form [name="username"]').value = body.username;
    form.reset(); // ล้างค่าฟอร์ม register กลับเป็นค่าว่าง เตรียมพร้อมสำหรับสมัครคนถัดไป
  }
});

// ---------- Login ----------

// ผูก event "submit" ของฟอร์มเข้าสู่ระบบ — ทำงานเมื่อกดปุ่ม "เข้าสู่ระบบ"
document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault(); // กัน browser reload หน้าเว็บ
  const form = e.target;
  // อ่าน username/password จากฟอร์มมาประกอบเป็น body
  const body = {
    username: form.username.value,
    password: form.password.value,
  };

  // เรียก POST /api/login
  const { ok, status, data } = await apiFetch('/api/login', {
    method: 'POST',
    body: JSON.stringify(body),
  });

  // แสดงผลลัพธ์ในกล่องผลลัพธ์ของแท็บ login
  showResult(document.getElementById('login-result'), ok, status, data);

  if (ok) {
    setToken(data.token); // login สำเร็จ — เก็บ token ที่ได้ไว้ใช้เรียก API อื่นต่อไป
    updateUserBadge(); // อัปเดต badge มุมขวาบนให้แสดง username/role ทันที
    switchTab('profile'); // พาผู้ใช้ไปหน้าโปรไฟล์
    document.getElementById('load-profile-btn').click(); // จำลองการกดปุ่ม "โหลดโปรไฟล์" ให้อัตโนมัติ
  }
});

// ---------- Profile ----------

// ผูก event คลิกให้ปุ่ม "โหลดข้อมูลโปรไฟล์" — เรียก GET /api/profile (มี token แนบไปด้วยผ่าน apiFetch)
document.getElementById('load-profile-btn').addEventListener('click', async () => {
  const { ok, status, data } = await apiFetch('/api/profile');
  showResult(document.getElementById('profile-result'), ok, status, data);
});

// ---------- Admin dashboard / RBAC ----------

// ผูก event คลิกให้ปุ่มเรียก GET /api/admin-dashboard — จะสำเร็จ (200) เฉพาะ user ที่ role เป็น admin เท่านั้น
document.getElementById('load-dashboard-btn').addEventListener('click', async () => {
  const { ok, status, data } = await apiFetch('/api/admin-dashboard');
  showResult(document.getElementById('admin-result'), ok, status, data);
});

// ผูก event คลิกให้ปุ่มโหลดรายชื่อ user ทั้งหมด — เรียก GET /api/users (เฉพาะ admin เช่นกัน)
document.getElementById('load-users-btn').addEventListener('click', async () => {
  const { ok, status, data } = await apiFetch('/api/users');
  // แสดงผลลัพธ์ดิบ (JSON) ในกล่องผลลัพธ์เหมือนปุ่มอื่น ๆ ก่อน
  showResult(document.getElementById('admin-result'), ok, status, data);

  const table = document.getElementById('users-table'); // ตารางที่จะใช้แสดงรายชื่อ user
  const tbody = table.querySelector('tbody'); // ส่วน tbody ที่จะเติมแถวข้อมูลเข้าไป

  if (!ok) {
    // ถูกปฏิเสธ (เช่น role เป็น member) — ไม่มีข้อมูล users ให้แสดง จึงซ่อนตารางไว้เหมือนเดิม
    table.classList.add('hidden');
    return;
  }

  tbody.innerHTML = ''; // ล้างแถวเก่าที่เคยแสดงไว้ทิ้งก่อน ป้องกันข้อมูลซ้ำซ้อนเวลากดโหลดซ้ำ
  // วนลูปสร้างแถวตารางใหม่ทีละ 1 แถวต่อ user 1 คนที่ได้จาก API
  data.users.forEach((u) => {
    const tr = document.createElement('tr'); // สร้าง <tr> เปล่าขึ้นมาใหม่
    // ใส่ข้อมูลแต่ละคอลัมน์ลงใน <tr> นั้น รวมถึง role badge สีตาม role และแปลงวันที่ให้อ่านง่ายแบบไทย
    tr.innerHTML = `
      <td>${u.id}</td>
      <td>${u.username}</td>
      <td><span class="role-badge ${u.role}">${u.role}</span></td>
      <td>${new Date(u.created_at).toLocaleString('th-TH')}</td>
    `;
    tbody.appendChild(tr); // เพิ่มแถวที่สร้างเสร็จแล้วเข้าไปในตาราง
  });
  table.classList.remove('hidden'); // มีข้อมูลแล้ว — เอา class ที่ซ่อนตารางออก ให้แสดงผลบนหน้าจอ
});

// ---------- Init ----------

// เมื่อไฟล์นี้ถูกโหลดครั้งแรก (ทุกครั้งที่เปิด/รีเฟรชหน้าเว็บ) ให้ตรวจสอบสถานะ login ทันที
updateUserBadge(); // ถ้ามี token ที่ยังใช้ได้ค้างอยู่ใน localStorage จะแสดง badge ทันทีโดยไม่ต้อง login ใหม่
if (getToken()) switchTab('profile'); // ถ้ามี token อยู่แล้ว ให้เปิดแท็บโปรไฟล์ไว้เลย สะดวกกว่าเริ่มที่หน้า register
