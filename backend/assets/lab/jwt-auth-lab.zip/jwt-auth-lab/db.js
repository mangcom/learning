// mysql2/promise คือ driver สำหรับต่อ MySQL/MariaDB ที่ใช้งานแบบ async/await ได้เลย
// (ต่างจาก mysql2 ธรรมดาที่ต้องใช้ callback)
const mysql = require('mysql2/promise');

// createPool สร้าง "pool" ของ connection ไว้ล่วงหน้า แทนที่จะเปิด-ปิด connection
// ใหม่ทุกครั้งที่มี request เข้ามา (เปิด connection ใหม่ทุกครั้งจะช้าและกิน resource มาก)
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost', // ชื่อ host ของ MariaDB (ใน docker compose คือ "mariadb")
  port: process.env.DB_PORT || 3306, // port มาตรฐานของ MySQL/MariaDB
  user: process.env.DB_USER, // username ที่ใช้ล็อกอินเข้า MariaDB
  password: process.env.DB_PASSWORD, // password ของ user ข้างต้น
  database: process.env.DB_NAME, // ชื่อฐานข้อมูลที่จะใช้งาน (ต้องมีอยู่แล้ว)
  waitForConnections: true, // ถ้า connection ใน pool ถูกใช้หมด ให้ "รอคิว" แทนที่จะโยน error ทันที
  connectionLimit: 10, // จำนวน connection สูงสุดที่ pool จะเปิดพร้อมกัน
});

// รอ MariaDB container พร้อมใช้งานก่อน (แม้จะมี depends_on/healthcheck แล้วก็ตาม
// เผื่อกรณีรันนอก docker compose หรือ MariaDB ยังไม่ accept connection ทัน)
// retries = ลองสูงสุดกี่ครั้ง, delayMs = รอกี่มิลลิวินาทีก่อนลองใหม่แต่ละครั้ง
async function waitForDb(retries = 15, delayMs = 2000) {
  // วนลองเชื่อมต่อทีละครั้ง ตั้งแต่ attempt ที่ 1 ถึง retries
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      // ขอยืม connection จาก pool มาสักตัว เพื่อทดสอบว่าต่อฐานข้อมูลได้จริง
      const conn = await pool.getConnection();
      // คืน connection กลับเข้า pool ทันที (แค่ทดสอบ ไม่ได้จะ query อะไร)
      conn.release();
      console.log('เชื่อมต่อ MariaDB สำเร็จ');
      return; // เชื่อมต่อสำเร็จแล้ว ออกจากฟังก์ชันได้เลย ไม่ต้องลองซ้ำอีก
    } catch (err) {
      // เชื่อมต่อไม่สำเร็จ (เช่น MariaDB container ยังสตาร์ทไม่เสร็จ) แสดง log ว่าลองครั้งที่เท่าไหร่
      console.log(`เชื่อมต่อ MariaDB ไม่สำเร็จ (ครั้งที่ ${attempt}/${retries}): ${err.message}`);
      // ถ้าลองครบจำนวนครั้งสูงสุดแล้วยังไม่สำเร็จ ให้โยน error ออกไปจริง ๆ (หยุดพยายามต่อ)
      if (attempt === retries) throw err;
      // ยังไม่ครบจำนวนครั้ง ให้หน่วงเวลาก่อนวน loop ไปลองใหม่รอบถัดไป
      await new Promise((r) => setTimeout(r, delayMs));
    }
  }
}

// export ทั้ง pool (ไว้ query ข้อมูลจริงใน auth-server.js) และ waitForDb (ไว้เรียกตอน server เริ่มทำงาน)
module.exports = { pool, waitForDb };
